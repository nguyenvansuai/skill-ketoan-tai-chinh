---
name: thue-nha-thau
description: Tính thuế nhà thầu nước ngoài (FCT) cho doanh nghiệp nhỏ và vừa Việt Nam năm 2026 — khi trả tiền cho tổ chức, cá nhân nước ngoài không có cơ sở thường trú (dịch vụ, phần mềm, tư vấn, bản quyền, lãi vay, cho thuê máy móc, xây lắp, vận chuyển): tỷ lệ GTGT (1%, 2%, 3%, 5%) và TNDN (0,1%–10%) theo ngành, hợp đồng giá net phải quy đổi gross-up hoặc giá gross khấu trừ khi trả, quy đổi ngoại tệ, bút toán 331/3338/1331, khai theo từng lần thanh toán, hiệp định tránh đánh thuế hai lần, mua quảng cáo Facebook, Google, TikTok và SaaS từ nhà cung cấp đã đăng ký thuế tại Việt Nam. Dùng khi người dùng hỏi "thuế nhà thầu", "FCT", "trả tiền cho công ty nước ngoài", "hợp đồng net phải nộp thuế bao nhiêu", "mua phần mềm nước ngoài có phải khấu trừ thuế", "quảng cáo Facebook có chịu thuế nhà thầu không".
---

# Thuế nhà thầu nước ngoài

Đọc `references/nguyen-tac-chung.md`, `references/thue-dn-2026.md` (mục 5); căn cứ ở `references/van-ban-hieu-luc.md` (mục 6). Toàn bộ tỷ lệ là **nguồn thứ cấp** → luôn kèm **[cần kiểm tra]**.

## 1. Xác định trước khi tính (hỏi gộp)

- Bên nước ngoài là ai, nước nào, có **cơ sở thường trú** hay đăng ký thuế tại Việt Nam không.
- Nội dung thanh toán (dịch vụ, bản quyền, lãi vay, hàng hóa kèm dịch vụ…) – theo hợp đồng và hóa đơn, không theo tên gọi.
- Giá hợp đồng **net** (bên Việt Nam chịu thuế) hay **gross** (đã gồm thuế); đồng tiền, tỷ giá; thanh toán một lần hay nhiều lần.
- Dịch vụ số qua nền tảng (quảng cáo Facebook, Google, TikTok; SaaS; cloud; app store): nhà cung cấp **đã đăng ký, tự khai nộp thuế tại Việt Nam** chưa (tra trên trang của cơ quan thuế dành cho nhà cung cấp nước ngoài). Đã đăng ký thì bên mua thường không khấu trừ lại; chưa đăng ký hoặc chưa rõ → **[cần kiểm tra]**, hỏi cơ quan thuế, lưu hóa đơn và chứng từ thanh toán.

## 2. Chạy script

```bash
python3 scripts/tinh_thue_nha_thau.py --hoat-dong dich-vu --gia 100000000 --loai net
python3 scripts/tinh_thue_nha_thau.py --hoat-dong dich-vu --gia 2000 --ngoai-te USD --ty-gia 25400 --loai net
python3 scripts/tinh_thue_nha_thau.py --hoat-dong ban-quyen --gia 50000000 --loai gross --gtgt kct
```

Hoạt động: `hang-hoa`, `dich-vu`, `dich-vu-gan-hang-hoa`, `nha-hang-khach-san`, `lai-vay`, `ban-quyen`, `cho-thue-may-moc`, `cho-thue-may-bay-tau-bien`, `xay-lap-khong-vat-tu`, `xay-lap-co-vat-tu`, `van-chuyen`, `khac`.

- Bản quyền, chuyển giao công nghệ, phần mềm: script **bắt nhập** `--gtgt kct` hoặc tỷ lệ – phải xác định có thuộc diện không chịu GTGT không.
- Hiệp định thuế được miễn, giảm TNDN: chỉ dùng `--tndn` sau khi có hồ sơ áp dụng hiệp định (TT 95/2026).
- Hợp đồng nhiều hoạt động: tính riêng từng phần; không tách được thì xét áp tỷ lệ cao nhất **[cần kiểm tra]**.

## 3. Quy tắc phải nói đúng

- Phương pháp trực tiếp: **bên Việt Nam khấu trừ, khai, nộp thay** theo từng lần thanh toán (được đăng ký khai tháng nếu thanh toán nhiều lần), quyết toán khi kết thúc hợp đồng (TT 89/2026 – TC). Hạn khai theo từng lần phát sinh: ngày thứ 10 kể từ ngày phát sinh **[cần kiểm tra quy định riêng cho nhà thầu]**.
- Công thức gross-up với giá net là cách quy đổi phổ biến – **[cần kiểm tra TT 20/2026]** trước khi khai.
- GTGT nộp thay được khấu trừ đầu vào khi có **chứng từ nộp thuế thay** (Luật 48/2024 Đ.14 k.2 điểm a). TNDN nộp thay là chi phí của DN khi hợp đồng quy định bên Việt Nam chịu **[cần kiểm tra điều kiện được trừ]**.
- Không tư vấn chia nhỏ hợp đồng, đổi tên nội dung thanh toán để giảm tỷ lệ.

## 4. Đầu ra

1. Bảng tính: doanh thu tính GTGT, TNDN, thuế từng loại, tiền chuyển nhà thầu, tổng chi của DN; "Đã kiểm tra phép tính".
2. Bút toán: Nợ 6421/6422/242/211 và Nợ 1331 / Có 331; Nợ 331 / Có 3338 (thuế khấu trừ); Nợ 3338 / Có 112 (nộp thuế); Nợ 331 / Có 112 (trả nhà thầu).
3. Bảng **Cần anh/chị kiểm tra**: tỷ lệ áp dụng, tình trạng đăng ký thuế của nhà cung cấp, hiệp định thuế, tỷ giá.
4. Câu chốt: "Đối chiếu văn bản hiện hành và hỏi cơ quan thuế quản lý trước khi kê khai."
